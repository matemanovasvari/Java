import java.util.Scanner;

public class PrimaJatek {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Add meg a csoki gyartasi sorszamat:");
        int id = scanner.nextInt();

        if (id <= 1) {
            System.out.println("Sajnos nem nyert!");
        }

        if(id == 2){
            System.out.println("Gratulalok, nyertel!");
        }
        
        for (int i = 3; i <= Math.sqrt(id); i += 2) {
            if (id % i == 0){
                System.out.println("Sajnos nem nyert!");
            }
            else{
                System.out.println("Gratulalok, nyertel!");
            }
        }

    }
}
