import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please enter a number!:");
        int number = scanner.nextInt();

        System.out.println("Please enter another number!:");
        int number2 = scanner.nextInt();

        System.out.println("Az intervallum also vegpontja:" + number);
        System.out.println("Az intervallum felso vegpontja:" + number2);

        int sum = 0;
        for (int i = number; i <= number2; i++) {
            if (i % 2 == 0) {
                sum += i;
            }
        }
        System.out.println("A(z) [" + number + ";" + number2 + "] intervallumba eso paros szamok osszege:" + sum);
    }
}